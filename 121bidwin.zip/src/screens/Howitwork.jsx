import React from "react";
import Footer from "../components/common/Footer";
import Header from "../components/common/Header";
import About from "../components/HowitWork/About";

const Howitwork = () => {
  return (
    <div>
      <Header />
      <About />
      <Footer />
    </div>
  );
};

export default Howitwork;

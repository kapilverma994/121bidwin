import React from "react";
import Footer from "../components/common/Footer";
import Header from "../components/common/Header";
import Card from "../components/Membership/Card";

const Membership = () => {
  return (
    <div>
      <Header />
      <Card />
      <Footer />
    </div>
  );
};

export default Membership;

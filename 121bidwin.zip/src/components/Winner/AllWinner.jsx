import React from "react";

const AllWinner = () => {
  return (
    <div>
      <div className="container-fluid">
        <div className="alclck">
          <h5 className="text-white bg-dark p-2">All Winners</h5>
          <div className="row">
            <div className="col-md-6">
              <ul className="ulal-win">
                <li>Mr. Anil Kumar</li>
                <li>Mr. Anil Kumar</li>
                <li>Mr. Anil Kumar</li>
                <li>Mr. Anil Kumar</li>
                <li>Mr. Anil Kumar</li>
                <li>Mr. Anil Kumar</li>
                <li>Mr. Anil Kumar</li>
                <li>Mr. Anil Kumar</li>
                <li>Mr. Anil Kumar</li>
                <li>Mr. Anil Kumar</li>
                <li>Mr. Anil Kumar</li>
                <li>Mr. Anil Kumar</li>
                <li>Mr. Anil Kumar</li>
                <li>Mr. Anil Kumar</li>
                <li>Mr. Anil Kumar</li>
                <li>Mr. Anil Kumar</li>
              </ul>
            </div>
            <div className="col-md-6">
              <ul className="ulal-win">
                <li>Mr. Anil Kumar</li>
                <li>Mr. Anil Kumar</li>
                <li>Mr. Anil Kumar</li>
                <li>Mr. Anil Kumar</li>
                <li>Mr. Anil Kumar</li>
                <li>Mr. Anil Kumar</li>
                <li>Mr. Anil Kumar</li>
                <li>Mr. Anil Kumar</li>
                <li>Mr. Anil Kumar</li>
                <li>Mr. Anil Kumar</li>
                <li>Mr. Anil Kumar</li>
                <li>Mr. Anil Kumar</li>
                <li>Mr. Anil Kumar</li>
                <li>Mr. Anil Kumar</li>
                <li>Mr. Anil Kumar</li>
                <li>Mr. Anil Kumar</li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default AllWinner;

import React from "react";
import { Col, Row } from "react-bootstrap";
import ProductCard from "./ProductCard";

const HomeProduct = () => {
  return (
    <div>
      <Row>
        <Col
          md={4}
          lg={3}
          xl={2}
          className="col-6 col-md-4 col-lg-3 col-xl-2 p-0"
        >
          <ProductCard />
        </Col>
        <Col
          md={4}
          lg={3}
          xl={2}
          className="col-6 col-md-4 col-lg-3 col-xl-2 p-0"
        >
          <ProductCard />
        </Col>
        <Col
          md={4}
          lg={3}
          xl={2}
          className="col-6 col-md-4 col-lg-3 col-xl-2 p-0"
        >
          <ProductCard />
        </Col>
        <Col
          md={4}
          lg={3}
          xl={2}
          className="col-6 col-md-4 col-lg-3 col-xl-2 p-0"
        >
          <ProductCard />
        </Col>
        <Col
          md={4}
          lg={3}
          xl={2}
          className="col-6 col-md-4 col-lg-3 col-xl-2 p-0"
        >
          <ProductCard />
        </Col>
        <Col
          md={4}
          lg={3}
          xl={2}
          className="col-6 col-md-4 col-lg-3 col-xl-2 p-0"
        >
          <ProductCard />
        </Col>
        <Col
          md={4}
          lg={3}
          xl={2}
          className="col-6 col-md-4 col-lg-3 col-xl-2 p-0"
        >
          <ProductCard />
        </Col>
        <Col
          md={4}
          lg={3}
          xl={2}
          className="col-6 col-md-4 col-lg-3 col-xl-2 p-0"
        >
          <ProductCard />
        </Col>
        <Col
          md={4}
          lg={3}
          xl={2}
          className="col-6 col-md-4 col-lg-3 col-xl-2 p-0"
        >
          <ProductCard />
        </Col>
        <Col
          md={4}
          lg={3}
          xl={2}
          className="col-6 col-md-4 col-lg-3 col-xl-2 p-0"
        >
          <ProductCard />
        </Col>
        <Col
          md={4}
          lg={3}
          xl={2}
          className="col-6 col-md-4 col-lg-3 col-xl-2 p-0"
        >
          <ProductCard />
        </Col>
        <Col
          md={4}
          lg={3}
          xl={2}
          className="col-6 col-md-4 col-lg-3 col-xl-2 p-0"
        >
          <ProductCard />
        </Col>
      </Row>
    </div>
  );
};

export default HomeProduct;

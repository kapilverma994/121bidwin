<div class="mt-4">
	<h4 class="pb-2 border-bottom">Create Product Category</h4>
	<form class="form" id="prod-category">
		<div class="row mt-4">
			<div class="col-sm-6">
				<div class="form-group">
					<label>Product Category Name</label>
					<input type="text" class="form-control">
				</div>
			</div>
		</div>
		
		<div class="form-group mt-4">
			<button type="submit" value="Update" class="btn btn-danger btn-md mr-4">Update</button>
			<button type="submit" value="Submit" class="btn btn-dark btn-md">Save</button>
		</div>
		
	</form>
</div>